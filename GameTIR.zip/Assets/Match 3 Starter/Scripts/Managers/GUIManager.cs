﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;


public class GUIManager : MonoBehaviour {
	public static GUIManager instance;
	
	public GameObject gameOverPanel;
	public Text yourScoreTxt;
	public Text highScoreTxt;

	public Text scoreTxt;
	public Text moveCounterTxt;

	public Animator contentPanel; //анимация

	private int score; //счетчик очков
	private int moveCounter; //счетчик ходов


	public void ToggleMenu() //скользящее меню
	{
		bool isHidden = contentPanel.GetBool("IsHidden"); //устанавливаем правильное значение IsHidden
		contentPanel.SetBool("IsHidden", !isHidden);
	}

	//обновляем UI Text, когда изменяется значение
	public int Score //счетчик очков
	{
		get
		{
			return score;
		}

		set
		{
			score = value;
			scoreTxt.text = score.ToString();
		}
	}

	public int MoveCounter //счетчик кол-ва шагов
	{
		get
		{
			return moveCounter;
		}

		set
		{
			moveCounter = value;
			if (moveCounter <= 0) //если шаги закончились
			{
				moveCounter = 0;
				StartCoroutine(WaitForShifting()); //конец игры

			}
			moveCounterTxt.text = moveCounter.ToString();
		}
	}

	private IEnumerator WaitForShifting() //позволяет завершить игру после всех действий игрока
	{
		yield return new WaitUntil(() => !BoardManager.instance.IsShifting);
		yield return new WaitForSeconds(.25f);
		GameOver(); //конец игры
	}

		void Awake() {
		moveCounter = 60; //количество ходов, которые может сделать игрок
		moveCounterTxt.text = moveCounter.ToString();
		instance = GetComponent<GUIManager>();
	}

	//Окно конца игры
	public void GameOver() {
		GameManager.instance.gameOver = true;

		gameOverPanel.SetActive(true);

		if (score > PlayerPrefs.GetInt("HighScore")) {
			PlayerPrefs.SetInt("HighScore", score);
			highScoreTxt.text = "Новый рекорд: " + PlayerPrefs.GetInt("HighScore").ToString();
		} else {
			highScoreTxt.text = "Рекорд: " + PlayerPrefs.GetInt("HighScore").ToString();
		}

		yourScoreTxt.text = score.ToString();
	}

	//настройки
	public void LowSettings()
    {
		QualitySettings.SetQualityLevel(0, true);
    }

	public void MediumSettings()
	{
		QualitySettings.SetQualityLevel(1, true);
	}

	public void HighSettings()
	{
		QualitySettings.SetQualityLevel(2, true);
	}

}
