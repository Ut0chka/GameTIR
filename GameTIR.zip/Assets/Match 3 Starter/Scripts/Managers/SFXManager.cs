﻿using UnityEngine;

public enum Clip { Select, Swap, Clear };

public class SFXManager : MonoBehaviour {
	public static SFXManager instance;

	private AudioSource[] sfx;

	// Инициализация музыки
	void Start () {
		instance = GetComponent<SFXManager>();
		sfx = GetComponents<AudioSource>();
    }

	//Запуск музыки
	public void PlaySFX(Clip audioClip) {
		sfx[(int)audioClip].Play();
	}
}
