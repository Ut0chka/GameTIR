﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BoardManager : MonoBehaviour {
	public static BoardManager instance; //сценарий использует шаблон Singleton со статической переменной с именем instance, что позволяет вызывать его из любого сценария
	public List<Sprite> characters = new List<Sprite>(); //полный список спрайтов, которые будут использоваться в качестве фрагментов плиток
	public GameObject tile; //префаб плитки игрового объекта, который будет создан при генерации игрового поля
	public int xSize, ySize; //размеры X и Y платы

	private GameObject[,] tiles; //двумерный массив с именами плиток, который будет использоваться для хранения плиток на доске

	public bool IsShifting { get; set; } //когда совпадение найдено, игровое поле пополняется новыми плитками

	void Start () {
		instance = GetComponent<BoardManager>();

		Vector2 offset = tile.GetComponent<SpriteRenderer>().bounds.size;
        CreateBoard(offset.x, offset.y); //передаем границы размера спрайта тайтла
    }

	private void CreateBoard (float xOffset, float yOffset) 
	{
		tiles = new GameObject[xSize, ySize]; //создаем плитки 2д-массива

        float startX = transform.position.x; //стартовые позиции для генерации доски
		float startY = transform.position.y;

		Sprite[] previousLeft = new Sprite[ySize]; //переменные для хранения ссылки на соседние плитки
		Sprite previousBelow = null;
		for (int x = 0; x < xSize; x++) { //получаем сетку из строк и столбцов
			for (int y = 0; y < ySize; y++) {
				GameObject newTile = Instantiate(tile, new Vector3(startX + (xOffset * x), startY + (yOffset * y), 0), tile.transform.rotation);
				tiles[x, y] = newTile;
				newTile.transform.parent = transform; //Добавляем все тайтлы
				List<Sprite> possibleCharacters = new List<Sprite>(); //список возможных поиток для спрайта
				possibleCharacters.AddRange(characters); //добавление плиток

				possibleCharacters.Remove(previousLeft[y]); //удаление плиток слева и снизу
				possibleCharacters.Remove(previousBelow);
				Sprite newSprite = possibleCharacters[Random.Range(0, possibleCharacters.Count)]; //Случайным образом выбирается спрайт, который уже перетаскивался
				newTile.GetComponent<SpriteRenderer>().sprite = newSprite; //Устанавливается спрайт вновь созданной плитки на случайно выбранный спрайт
				previousLeft[y] = newSprite; //слева
				previousBelow = newSprite; //снизу
			}
        }
    }

	public IEnumerator FindNullTiles() //поиск пустых тайлов после удаления плиток
	{
		for (int x = 0; x < xSize; x++) //проходимся по всему полю
		{
			for (int y = 0; y < ySize; y++)
			{
				if (tiles[x, y].GetComponent<SpriteRenderer>().sprite == null)
				{
					yield return StartCoroutine(ShiftTilesDown(x, y)); //плитки опускаются вниз
					break;
				}
			}
		}
		for (int x = 0; x < xSize; x++)
		{
			for (int y = 0; y < ySize; y++)
			{
				tiles[x, y].GetComponent<Tile>().ClearAllMatches();
			}
		}
	}

	private IEnumerator ShiftTilesDown(int x, int yStart, float shiftDelay = .03f) //обработка фактического смещения
	{
		IsShifting = true;
		List<SpriteRenderer> renders = new List<SpriteRenderer>();
		int nullCount = 0;

		for (int y = yStart; y < ySize; y++) //Перебираем плитки и находит, сколько пробелов нужно для смещения вниз
		{  
			SpriteRenderer render = tiles[x, y].GetComponent<SpriteRenderer>();
			if (render.sprite == null)
			{ 
				nullCount++; //Сохраняем количество пустых тайлов
			}
			renders.Add(render);
		}

		for (int i = 0; i < nullCount; i++) //Повторяем цикл, чтобы начать фактическое переключение
		{
			GUIManager.instance.Score += 50; //+50 очков за опустошение тайтла
			yield return new WaitForSeconds(shiftDelay); //пауза в секундах
			for (int k = 0; k < renders.Count - 1; k++) //перебирает каждый спрайтрендер в списке рендеров
			{ 
				renders[k].sprite = renders[k + 1].sprite; //меняем местами каждый спрайт с тем, который был найден над ним
				renders[k + 1].sprite = GetNewSprite(x, ySize - 1); //до тех пор, пока не будет достигнут конец и последний спрайт не будет установлен на ноль
			}
		}
		IsShifting = false;
	}

	private Sprite GetNewSprite(int x, int y) //создает список возможных символов, которыми может быть заполнен спрайт
	{
		List<Sprite> possibleCharacters = new List<Sprite>();
		possibleCharacters.AddRange(characters);

		//используем серию операторов if для того, чтобы не происходило выхода за границы игрового поля
		if (x > 0)
		{
			possibleCharacters.Remove(tiles[x - 1, y].GetComponent<SpriteRenderer>().sprite); //удаляются возможные дубликаты
		}
		if (x < xSize - 1)
		{
			possibleCharacters.Remove(tiles[x + 1, y].GetComponent<SpriteRenderer>().sprite); //удаляются возможные дубликаты
		}
		if (y > 0)
		{
			possibleCharacters.Remove(tiles[x, y - 1].GetComponent<SpriteRenderer>().sprite); //удаляются возможные дубликаты
		}

		return possibleCharacters[Random.Range(0, possibleCharacters.Count)]; //возвращается случайный спрайт из списка возможных спрайтов
	}
}
