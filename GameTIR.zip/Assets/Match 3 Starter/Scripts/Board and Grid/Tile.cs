﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Tile : MonoBehaviour 
{
	private static Color selectedColor = new Color(.5f, .5f, .5f, 1.0f);
	private static Tile previousSelected = null;

	private SpriteRenderer render;
	private bool isSelected = false;

	private Vector2[] adjacentDirections = new Vector2[] { Vector2.up, Vector2.down, Vector2.left, Vector2.right };

	private bool matchFound = false; //поиск совпадений спрайтов

	void Awake() {
		render = GetComponent<SpriteRenderer>();
    }

	private void Select() //сообщает игре, что этот фрагмент плитки выбран, меняет цвет плитки и воспроизводит звуковой эффект выбора
	{ 
		isSelected = true;
		render.color = selectedColor;
		previousSelected = gameObject.GetComponent<Tile>();
		SFXManager.instance.PlaySFX(Clip.Select);
	}

	private void Deselect() //возвращает спрайт к его первоначальному цвету и сообщает игре, что в данный момент объект не выбран
	{
		isSelected = false;
		render.color = Color.white;
		previousSelected = null;
	}
	
	void OnMouseDown()
	{
		if (render.sprite == null || BoardManager.instance.IsShifting) //проверка разрешения выбора плитки
		{		
			return;
		}

		if (isSelected) //выбрать или отменить выбор
		{ 
			Deselect();
		}
		else
		{
			if (previousSelected == null) //проверяем не выбрана ли другая плитка
			{ 
				Select();
			}
			else
			{
				if (GetAllAdjacentTiles().Contains(previousSelected.gameObject)) //проверка, находится ли игровой объект в списке соседних плиток
				{ 
					SwapSprite(previousSelected.render); //если да, то меняем местами
					previousSelected.ClearAllMatches(); // проверка соответствия
					previousSelected.Deselect(); //отмена выбора
					ClearAllMatches(); //если после свапа имеется еще совпадение
				}
				else 
				{ 
					previousSelected.GetComponent<Tile>().Deselect(); //если нет, то отмена выбора
					Select(); //выбираем новую плитку
				}
			}
		}
	}

	public void SwapSprite(SpriteRenderer render2) //обмен плитками
	{
		if (render.sprite == render2.sprite) //если две плитки одинаковые, то обмен не осуществится
		{
			return;
		}

		Sprite tempSprite = render2.sprite; //сохраняем плитку
		render2.sprite = render.sprite; //меняем местами плитки
		render.sprite = tempSprite;
		SFXManager.instance.PlaySFX(Clip.Swap); //звуковой эффект
		GUIManager.instance.MoveCounter--; //уменьшаем количество шагов
	}

	private GameObject GetAdjacent(Vector2 castDir) //получение информации о соседней плитке
	{
		RaycastHit2D hit = Physics2D.Raycast(transform.position, castDir); //castDir - указатель на цель
		if (hit.collider != null) //если в этом направлении найден тайтл
		{
			return hit.collider.gameObject;
		}
		return null;
	}

	private List<GameObject> GetAllAdjacentTiles() //генерация списка плиток, окружающих текущую плитку
	{
		List<GameObject> adjacentTiles = new List<GameObject>();
		for (int i = 0; i < adjacentDirections.Length; i++)
		{
			adjacentTiles.Add(GetAdjacent(adjacentDirections[i]));
		}
		return adjacentTiles;
	}

	private List<GameObject> FindMatch(Vector2 castDir) //принимает параметр, в котором будут запускаться все лучи к тайлам
	{ 
		List<GameObject> matchingTiles = new List<GameObject>(); //создаем новый список для хранения всех существующих плиток
		RaycastHit2D hit = Physics2D.Raycast(transform.position, castDir); //запускаем луч
		while (hit.collider != null && hit.collider.GetComponent<SpriteRenderer>().sprite == render.sprite) //пока луч не достигнет тайтла, либо спрайт тайлов будет отличаться от возвращенного спрайта объекта
		{ 
			matchingTiles.Add(hit.collider.gameObject); //добавляем в список все совпадения
			hit = Physics2D.Raycast(hit.collider.transform.position, castDir);
		}
		return matchingTiles; //возвращаем список совпадающих спрайтов
	}

	private void ClearMatch(Vector2[] paths) //нахождение всех совпадающих плиток по заданным путям
	{
		List<GameObject> matchingTiles = new List<GameObject>(); //хранение совпадений
		for (int i = 0; i < paths.Length; i++) 
		{
			matchingTiles.AddRange(FindMatch(paths[i])); //добавляем любые совпадения в список соответствия
		}
		if (matchingTiles.Count >= 2) //если найдено более двух совпадений(третье совпадение - всегда начальная плитка)
		{
			for (int i = 0; i < matchingTiles.Count; i++) 
			{
				matchingTiles[i].GetComponent<SpriteRenderer>().sprite = null; //перебираем подходящие плитки и удаляем их спрайты
			}
			matchFound = true; //совпадение найдено
		}
	}
	 
	public void ClearAllMatches() //очищение всех плиток
	{
		if (render.sprite == null)
        {
			return;
        }			


		ClearMatch(new Vector2[2] { Vector2.left, Vector2.right }); // вызываем ClearMatch как для вертикального, так и для горизонтального соответствия
		ClearMatch(new Vector2[2] { Vector2.up, Vector2.down });
		if (matchFound) //если совпадение найдено
		{
			render.sprite = null; //очищение спрайта
			matchFound = false; //сброс флага
			StopCoroutine(BoardManager.instance.FindNullTiles());
			StartCoroutine(BoardManager.instance.FindNullTiles());
			SFXManager.instance.PlaySFX(Clip.Clear); //звуковой эффект
		}

	}

}